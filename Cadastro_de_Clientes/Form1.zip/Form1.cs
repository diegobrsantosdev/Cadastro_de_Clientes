using MySql.Data.MySqlClient;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.ConstrainedExecution;

namespace Cadastro_de_Clientes
{
    public partial class CadCliente : Form
    {
        public CadCliente()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ConnectToDatabase();
            LoadComboBox();
            LoadComboBoxGenero();

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void BtNovo_Click(object sender, EventArgs e)
        {
            TxtNome.Text = "";
            TxtDoc.Text = "";
            TxtEmail.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (MySqlConnection Conexao = new MySqlConnection("Server=localhost;Port=3306;Database=cadastro_de_clientes;User=root"))
            {
                try
                {
                    Conexao.Open();
                    MessageBox.Show("Conex�o OK");

                    using (MySqlCommand cmd = Conexao.CreateCommand())
                    {
                        String nome = TxtNome.Text;
                        String cpf_cnpj = TxtDoc.Text;
                        String email = TxtEmail.Text;
                        ComboBoxItem selectedItem = (ComboBoxItem)CbCiivil.SelectedItem;
                        int codigoEstadoCivil = int.Parse(selectedItem.Value);
                        ComboBoxItem selectedItem2 = (ComboBoxItem)CbGenero.SelectedItem;
                        int codigoCbGenero = int.Parse(selectedItem2.Value);
                        String rg = TxtRG.Text;
                        DateTime dataNascimento = DateTime.Now;
                        String observacoes = TxtObs.Text;
                        String celular = TxtCelular.Text;
                        String cep = TxtCep.Text;
                        String endereco = CbEndereco.Text;
                        int numeroEndereco = int.Parse(TxtNumero.Text);
                        String bairro = CbBairro.Text;
                        String cidade = CbCidade.Text;
                        String estado = CbEstado.Text;
                        



                        cmd.CommandText = "INSERT INTO cliente (nome, CPF_CNPJ, CODIGO_ESTADO_CIVIL, CODIGO_GENERO, SN_SITUACAO_CADASTRAL, EMAIL, RG, DATA_NASCIMENTO, OBSERVACOES, CELULAR, CEP, ENDERECO, N_ENDERECO, BAIRRO, CIDADE, ESTADO, SITUACAO) VALUES (@nome, @CPF_CNPJ, @CODIGO_ESTADO_CIVIL, @CODIGO_GENERO, @SN_SITUACAO_CADASTRAL, @EMAIL, @RG, @DATA_NASCIMENTO, @OBSERVACOES, @CELULAR, @CEP, @ENDERECO, @N_ENDERECO, @BAIRRO, @CIDADE, @ESTADO, @SITUACAO)";

                        cmd.Parameters.AddWithValue("@nome", nome);
                        cmd.Parameters.AddWithValue("@CPF_CNPJ", cpf_cnpj);
                        cmd.Parameters.AddWithValue("@CODIGO_ESTADO_CIVIL", codigoEstadoCivil);
                        cmd.Parameters.AddWithValue("@CODIGO_GENERO", codigoCbGenero);
                        cmd.Parameters.AddWithValue("@SN_SITUACAO_CADASTRAL", "S");
                        cmd.Parameters.AddWithValue("@EMAIL", email);
                        cmd.Parameters.AddWithValue("@RG", rg);
                        cmd.Parameters.AddWithValue("@DATA_NASCIMENTO", dataNascimento);
                        cmd.Parameters.AddWithValue("@OBSERVACOES", observacoes);
                        cmd.Parameters.AddWithValue("@CELULAR", celular);
                        cmd.Parameters.AddWithValue("@CEP", cep);
                        cmd.Parameters.AddWithValue("@ENDERECO", endereco);
                        cmd.Parameters.AddWithValue("@N_ENDERECO", numeroEndereco);
                        cmd.Parameters.AddWithValue("@BAIRRO", bairro);
                        cmd.Parameters.AddWithValue("@CIDADE", cidade);
                        cmd.Parameters.AddWithValue("@ESTADO", estado);
                        



                        if (CkSituacao.Checked == true)
                        {
                            cmd.Parameters.AddWithValue("@SITUACAO", "Ativo");
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@SITUACAO", "Cancelado");
                        }

                        cmd.ExecuteNonQuery();
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void ConnectToDatabase()
        {

        }

        private void LoadComboBox()
        {
            string connectionString = "server=localhost;database=cadastro_de_clientes;user=root;";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT Codigo, nome FROM ESTADO_CIVIL";
                    MySqlCommand command = new MySqlCommand(query, connection);

                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        // Adiciona os valores ao ComboBox
                        CbCiivil.Items.Add(new ComboBoxItem(reader["nome"].ToString(), reader["codigo"].ToString()));
                    }

                    reader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }


        }
        private void LoadComboBoxGenero()
        {
            string connectionString = "server=localhost;database=cadastro_de_clientes;user=root;";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT Codigo, nome FROM GENERO";
                    MySqlCommand command = new MySqlCommand(query, connection);

                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        // Adiciona os valores ao ComboBox
                        CbGenero.Items.Add(new ComboBoxItem(reader["nome"].ToString(), reader["codigo"].ToString()));
                    }

                    reader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }


        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CbCiivil.SelectedItem != null)
            {
                ComboBoxItem selectedItem = (ComboBoxItem)CbCiivil.SelectedItem;
                string selectedText = selectedItem.Text;  // Nome do cliente
                string selectedValue = selectedItem.Value; // ID do cliente

                MessageBox.Show($"Nome: {selectedText}, ID: {selectedValue}");
            }
            if (CbGenero.SelectedItem != null)
            {
                ComboBoxItem selectedItem = (ComboBoxItem)CbGenero.SelectedItem;
                string selectedText = selectedItem.Text;  // Nome do cliente
                string selectedValue = selectedItem.Value; // ID do cliente

                MessageBox.Show($"Nome: {selectedText}, ID: {selectedValue}");
            }

        }

        private void CadCliente_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {


        }

        private void SalvarClienteMySQL()
        {
            using (MySqlConnection Conexao = new MySqlConnection("Server=localhost;Port=3306;Database=cadastro_de_clientes;User=root"))
            {
                try
                {
                    Conexao.Open();
                    MessageBox.Show("Conex�o OK");

                    using (MySqlCommand cmd = Conexao.CreateCommand())
                    {

                        cmd.ExecuteNonQuery();
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
        }

        private void CbEndereco_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public class ComboBoxItem
        {
            public string Text { get; set; }
            public string Value { get; set; }

            public ComboBoxItem(string text, string value)
            {
                Text = text;
                Value = value;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void botaoExcluir_SelectedIndexChange(object sender, EventArgs e)
        {
            if (CbCiivil.SelectedItem != null)
            {
                ComboBoxItem selectedItem = (ComboBoxItem)CbCiivil.SelectedItem;
                string selectedText = selectedItem.Text;  // Nome do cliente
                string selectedValue = selectedItem.Value; // ID do cliente

                MessageBox.Show($"Nome: {selectedText}, ID: {selectedValue}");
            }
            if (CbGenero.SelectedItem != null)
            {
                ComboBoxItem selectedItem = (ComboBoxItem)CbGenero.SelectedItem;
                string selectedText = selectedItem.Text;  // Nome do cliente
                string selectedValue = selectedItem.Value; // ID do cliente

                MessageBox.Show($"Nome: {selectedText}, ID: {selectedValue}");
            }

        }

    }
}

